//
//  MonitoringProtocol.swift
//  FBSnapshotTestCase
//
//  Created by Elkin.Salcedo on 12/14/20.
//

import Foundation

protocol MonitoringProtocol {
    func turnOn()
    func turnOff()
}
