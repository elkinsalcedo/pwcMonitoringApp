//
//  MonitoringConstants.swift
//  FBSnapshotTestCase
//
//  Created by Elkin.Salcedo on 12/14/20.
//

import Foundation

internal class MonitoringConstants {
    static let TIME_MONITORING = 30
}
