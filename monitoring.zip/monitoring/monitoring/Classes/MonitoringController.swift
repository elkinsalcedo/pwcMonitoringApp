//
//  MonitoringController.swift
//  monitoring
//
//  Created by Elkin Salcedo on 12/14/20.
//
import Foundation

@objcMembers
public class MonitoringController: NSObject {

    private var delegate: MonitoringDelegate!
    private var monitoring: MonitoringProtocol?

    public init(delegate: MonitoringDelegate) {
        super.init()

        self.monitoring = Monitoring(monitorInterval: MonitoringConstants.TIME_MONITORING, signal: Signal(), monitoringDelegate: delegate)
    }

    internal init(monitoring: MonitoringProtocol) {
        self.monitoring = monitoring
    }

    public func turnOn() {
        monitoring?.turnOn()
    }

    public func turnOff(){
        monitoring?.turnOff()
    }
}
