//
//  DataResponse.swift
//  remoting
//
//  Created by Elkin Salcedo on 12/14/20.
//

import Foundation

@objcMembers
public class DataResponse: NSObject {
    public var code: Int = 500
    public var data: Data = Data()
}
