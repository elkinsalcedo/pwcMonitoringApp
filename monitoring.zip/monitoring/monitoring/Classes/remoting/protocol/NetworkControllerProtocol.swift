//
//  NetworkControllerProtocol.swift
//  remoting
//
//  Created by Elkin Salcedo on 12/14/20.
//

import Foundation

@objc public protocol NetworkControllerProtocol {
    func getRequest(urlString: String, header: String, onResponse: @escaping(DataResponse) -> Void)
    func postRequest(urlString: String, header: String, body: Data, onResponse: @escaping(DataResponse) -> Void)
}
