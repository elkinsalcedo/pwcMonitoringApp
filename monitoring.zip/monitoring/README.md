# monitoring

[![CI Status](https://img.shields.io/travis/esalcedo/monitoring.svg?style=flat)](https://travis-ci.org/esalcedo/monitoring)
[![Version](https://img.shields.io/cocoapods/v/monitoring.svg?style=flat)](https://cocoapods.org/pods/monitoring)
[![License](https://img.shields.io/cocoapods/l/monitoring.svg?style=flat)](https://cocoapods.org/pods/monitoring)
[![Platform](https://img.shields.io/cocoapods/p/monitoring.svg?style=flat)](https://cocoapods.org/pods/monitoring)

## Example

To run the example project, clone the repo, and run `pod install` from the Example directory first.

## Requirements

## Installation

monitoring is available through [CocoaPods](https://cocoapods.org). To install
it, simply add the following line to your Podfile:

```ruby
pod 'monitoring'
```

## Author

esalcedo, esalcedo@easysol.net

## License

monitoring is available under the MIT license. See the LICENSE file for more info.
