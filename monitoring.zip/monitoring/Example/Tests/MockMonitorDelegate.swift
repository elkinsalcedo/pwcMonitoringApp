//
//  MockMonitorDelegate.swift
//  monitoring_Tests
//
//  Created by Elkin.Salcedo on 12/15/20.
//  Copyright © 2020 CocoaPods. All rights reserved.
//

import Foundation

@testable import monitoring
import XCTest

class MockMonitorDelegate: MonitoringDelegate {
    var status = false

    var expectationMock : XCTestExpectation!

    init(expectation : XCTestExpectation) {
        self.expectationMock = expectation
    }
    
    func signalStatus(status: Bool) {
        expectationMock.fulfill()
        
        self.status = status
    }
}
