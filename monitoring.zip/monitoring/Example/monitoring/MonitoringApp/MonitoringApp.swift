//
//  MonitoringApp.swift
//  monitoring_Example
//
//  Created by Elkin.Salcedo on 12/15/20.
//  Copyright © 2020 CocoaPods. All rights reserved.
//

import Foundation

import monitoring
class MonitoringApp: MonitoringAppProtocol {

    func turnOnMonitoring(delegate: MonitoringDelegate){
        MonitoringController(delegate: delegate).turnOn()
    }

}
