//
//  ViewControllerInteractor.swift
//  monitoring_Example
//
//  Created by Elkin.Salcedo on 12/15/20.
//  Copyright © 2020 CocoaPods. All rights reserved.
//

import Foundation
import monitoring

class ViewControllerInteractor: NSObject, InteractorAppProtocol {

    private var presenter: PresenterAppProtocol!

    func setPresenter(presenter: PresenterAppProtocol){
        self.presenter = presenter
    }

    func getProducts(){
        let url = "https://pwctestelkin-bancofuturo.free.beeceptor.com/api/getProducts"
        let header =  "application/json"

        NetworkController().getRequest(urlString : url, header: header, onResponse:
        { (dataResponse) in
            guard dataResponse.code != 200 else {
                do {
                    let data = try JSONDecoder().decode(ProductsModel.self, from: dataResponse.data)
                    DispatchQueue.main.async {
                        self.response(product: data)
                    }
                    return
                } catch {
                    return
                }
            }
            
            return
        })
    }

    func response(product: ProductsModel) {
        presenter.setProducts(products: product)
    }
}
