//
//  ViewController.swift
//  monitoring
//
//  Created by esalcedo on 12/14/2020.
//  Copyright (c) 2020 esalcedo. All rights reserved.
//

import UIKit

class ViewController: UIViewController, ViewControllerAppProtocol, UITableViewDelegate, UITableViewDataSource {

    @IBOutlet weak var lblStatusConnection: UILabel!
    @IBOutlet weak var lblMyProducts: UILabel!
    @IBOutlet weak var table: UITableView!
    var productList: [String] = []

    var presenter: PresenterAppProtocol!

    override func viewDidLoad() {
        super.viewDidLoad()

        presenter = ViewControllerPresenter(view: self, interactor: ViewControllerInteractor())
        presenter.initMonitoring()

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.isNavigationBarHidden = true
        presenter.getProducts()
    }

    func setStatusConnection(status: Bool){
        lblStatusConnection?.isHidden = status
    }

    func setProducts(products: ProductsModel) {
        productList.append(products.ctaahorro)
        productList.append(products.ctacorriente)
        productList.append(products.tc)
        productList.append(products.cred)

        table.reloadData()
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        let totalProducts = productList.count
        if (totalProducts == 0){
            table.isHidden = true
            lblMyProducts.text = "No hay productos a mostrar"
        }else{
            lblMyProducts.text = "Mis Productos"
            table.isHidden = false
        }

        return totalProducts
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "myCell", for: indexPath)
        cell.textLabel?.text = productList[indexPath.row]

        return cell
    }

}

