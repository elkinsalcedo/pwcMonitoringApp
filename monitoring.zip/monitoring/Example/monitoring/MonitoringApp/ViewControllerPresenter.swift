//
//  ViewControllerPresenter.swift
//  monitoring_Example
//
//  Created by Elkin.Salcedo on 12/15/20.
//  Copyright © 2020 CocoaPods. All rights reserved.
//

import Foundation
import monitoring
import UIKit

class ViewControllerPresenter: NSObject, PresenterAppProtocol, MonitoringDelegate {
    private var interactor: InteractorAppProtocol!
    private var viewDelegate: ViewControllerAppProtocol!

    init(view: ViewControllerAppProtocol, interactor: InteractorAppProtocol) {
        super.init()

        self.viewDelegate = view
        self.interactor = interactor
        self.interactor.setPresenter(presenter: self)
    }

    func initMonitoring(){
        MonitoringApp().turnOnMonitoring(delegate: self)
    }

    func getProducts(){
        interactor.getProducts()
    }

    func setProducts(products: ProductsModel) {
        viewDelegate.setProducts(products: products)
    }

    func signalStatus(status: Bool) {
        viewDelegate.setStatusConnection(status: status)
    }
}
