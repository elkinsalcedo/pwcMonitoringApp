//
//  MonitoringAppProtocol.swift
//  monitoring_Example
//
//  Created by Elkin.Salcedo on 12/15/20.
//  Copyright © 2020 CocoaPods. All rights reserved.
//

import Foundation
import monitoring

protocol ViewControllerAppProtocol {
    func setStatusConnection(status: Bool)
    func setProducts(products: ProductsModel)
}

protocol PresenterAppProtocol {
    func getProducts()
    func initMonitoring()
    func setProducts(products: ProductsModel)
}

protocol InteractorAppProtocol {
    func setPresenter(presenter: PresenterAppProtocol)
    func getProducts()
}

protocol MonitoringAppProtocol {
    func turnOnMonitoring(delegate: MonitoringDelegate)
}
