//
//  ProductsModel.swift
//  monitoring_Example
//
//  Created by Elkin.Salcedo on 12/15/20.
//  Copyright © 2020 CocoaPods. All rights reserved.
//

import Foundation

public struct ProductsModel: Codable {
    public private(set) var ctaahorro: String = ""
    public private(set) var ctacorriente: String = ""
    public private(set) var tc: String = ""
    public private(set) var cred: String = ""

    public init(ctaahorro: String, ctacorriente: String, tc: String, cred: String) {
        self.ctaahorro = ctaahorro
        self.ctacorriente = ctacorriente
        self.tc = tc
        self.cred = cred
    }

    public func toData() -> Data {
        return serverModelToData()
    }

    private func serverModelToData() -> Data {
        do {
            return try JSONEncoder().encode(self)
        } catch {
            return Data()
        }
    }
}
