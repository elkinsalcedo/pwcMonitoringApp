import XCTest
@testable import monitoring

class MonitoringControllerTests: XCTestCase {

    var monitoringController: MonitoringController?
    var monitoring: Monitoring?
    var expectation: XCTestExpectation!
    var mockSignal: MockSignal!
    var mockMonitorDelegate: MockMonitorDelegate?

    override func setUp() {
        expectation = expectation(description: "Signal")
        mockSignal = MockSignal()
        mockMonitorDelegate = MockMonitorDelegate(expectation: expectation)
        monitoringController = MonitoringController(monitoring: Monitoring(monitorInterval: 2, signal: mockSignal, monitoringDelegate: mockMonitorDelegate!))

        super.setUp()
    }
    
    override func tearDown() {
        monitoringController?.turnOff()

        monitoring = nil
        mockMonitorDelegate = nil
        monitoringController = nil

        super.tearDown()
    }
    
    func testMonitoringTurnOn_GivenSignalEnabled_WhenDetectSignal_Then_Return_SignalTrue() {
        mockSignal.signal = true
        
        monitoringController?.turnOn()

        waitForExpectations(timeout: 2)
        XCTAssertEqual(mockMonitorDelegate?.status, true)
    }

    func testMonitoringTurnOff_GivenSignalDisabled_WhenDetectSignal_Then_Return_SignalFalse() {
        mockSignal.signal = false

        monitoringController?.turnOn()

        waitForExpectations(timeout: 2)
        XCTAssertEqual(mockMonitorDelegate?.status, false)
    }
    
}
