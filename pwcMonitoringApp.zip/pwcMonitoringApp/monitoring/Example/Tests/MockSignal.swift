//
//  MockSignal.swift
//  monitoring_Tests
//
//  Created by Elkin.Salcedo on 12/15/20.
//  Copyright © 2020 CocoaPods. All rights reserved.
//

import Foundation
@testable import monitoring
import XCTest

class MockSignal: SignalProtocol {
    var signal = false

    func detectSignal() -> Bool {

        return signal
    }
}
