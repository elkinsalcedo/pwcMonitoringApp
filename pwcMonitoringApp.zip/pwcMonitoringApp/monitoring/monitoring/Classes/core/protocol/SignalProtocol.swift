//
//  SignalProtocol.swift
//
//  Created by Elkin.Salcedo on 12/14/20.
//

import Foundation

protocol SignalProtocol {
    func detectSignal() -> Bool
}
