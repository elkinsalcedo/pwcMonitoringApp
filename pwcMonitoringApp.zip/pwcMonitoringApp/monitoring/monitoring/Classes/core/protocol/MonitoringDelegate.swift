//
//  MonitoringDelegate.swift
//  FBSnapshotTestCase
//
//  Created by Elkin.Salcedo on 12/15/20.
//

import Foundation

public protocol MonitoringDelegate {
    func signalStatus (status: Bool)
}
