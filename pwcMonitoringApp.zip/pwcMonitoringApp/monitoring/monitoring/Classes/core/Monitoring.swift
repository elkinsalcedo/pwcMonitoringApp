//
//  Monitoring.swift
//  FBSnapshotTestCase
//
//  Created by Elkin.Salcedo on 12/14/20.
//

import Foundation
@available(iOS 10.0, *)
class Monitoring: MonitoringProtocol {

    private var timer: Timer?
    private var signal: SignalProtocol?
    private var monitorInterval: Int
    private var delegate: MonitoringDelegate?

    init(monitorInterval: Int, signal: SignalProtocol, monitoringDelegate: MonitoringDelegate) {
        self.monitorInterval = monitorInterval
        self.signal = signal
        self.delegate = monitoringDelegate
    }

    func turnOn(){
        DispatchQueue.main.async {
            self.timer = Timer.scheduledTimer(withTimeInterval: TimeInterval(self.monitorInterval), repeats: true) { timer in
                self.delegate?.signalStatus(status: self.detectSignal()!)
            }
        }
    }

    func turnOff() {
        timer?.invalidate()
    }

    private func detectSignal() -> Bool? {
        return signal?.detectSignal()
    }
}
